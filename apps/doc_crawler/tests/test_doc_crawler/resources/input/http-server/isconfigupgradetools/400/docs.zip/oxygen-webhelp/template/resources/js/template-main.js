// JavaScript Document
define(['require'], function (require) {
    require(['./fixclasses','./sharer','./simplebar']);
});